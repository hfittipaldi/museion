<?
include("classe_padrao.php");
$db=new conexao();
$db->conecta();
$sql="INSERT INTO menu_item values('$_REQUEST[menu_item]','$_REQUEST[menu_nome]','$_REQUEST[chamada]',
'$_REQUEST[posicao]','$_REQUEST[ordenacao]')";
$db->query($sql);
echo"<script>alert('Inclusao realizada com sucesso!')</script>";
echo"<script>location.href='itens2.php'</script>";

?>