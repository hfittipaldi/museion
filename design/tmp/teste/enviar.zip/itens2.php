
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
<style type="text/css">
<!--
.style5 {font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; }
-->
</style>
</head>

<body>
<div align="center">
  <table width="542" border="0" align="center" cellpadding="2" cellspacing="2" bgcolor="#FFFFFF">
    <tr align="center" class="style5">
      <td bgcolor="#DDDDDD">Menu Item </td>
      <td bgcolor="#DDDDDD">Menu_nome</td>
      <td bgcolor="#DDDDDD">Chamada</td>
      <td bgcolor="#DDDDDD">Posicao</td>
      <td bgcolor="#DDDDDD">Ordenacao</td>
    </tr>
<?php
require("classe_padrao.php");
$db=new conexao();
$db->conecta();
$sql="SELECT a.menu_item,a.menu_nome,chamada,posicao,ordenacao from menu_item as a ";
$db->query($sql);
$i=$db->contalinhas();
  if ($i > 0)
   {
     while ($linha = $db->dados())
      {
                $x=$linha['menu_item'];
                $y=$linha['menu_nome'];
				$w=$linha['chamada'];
				$z=$linha['posicao'];
				$a=$linha['ordenacao']
	

?> 
  <tr class="style5">
    <td width="88" class="marrom10b"><? echo $x ?></td>
      <td width="114" align="center" class="marrom11"><? echo $y ?></td>
      <td width="128" align="center" class="marrom11"><? echo $w ?></td>
      <td width="75" align="center" class="marrom11"><? echo $z ?>&nbsp;</td>
      <td width="105" align="center" class="marrom11"><? echo $a ?>&nbsp;</td>
  </tr>
  <? } }?>
  </table>
  <form name="form1" method="post" action="itens1.php">
    <table width="700" border="0">
      <tr>
        <td width="133"><span class="style5">Menu Item:
          <input name="menu_item" type="text" id="menu_item" size="5"> 
        </span></td>
        <td width="255"><span class="style5">Menu_nome:
          <input name="menu_nome" type="text" id="menu_nome">
        </span></td>
        <td width="298"><span class="style5">Chamada:
          <input name="chamada" type="text" id="chamada">
        </span></td>
      </tr>
      <tr class="style5">
        <td>Posicao:
        <input name="posicao" type="text" id="posicao" size="5"></td>
        <td>Ordenacao:
        <input name="ordenacao" type="text" id="ordenacao" size="5"></td>
        <td>&nbsp;</td>
      </tr>
    </table>
    <table width="700" border="0">
      <tr>
        <td><input type="submit" name="Submit" value="Enviar"></td>
      </tr>
    </table>
  </form>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>
</body>
</html>
